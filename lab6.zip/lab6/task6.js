const form = document.getElementById("orderForm");
const summary = document.getElementById("summary");
const summaryList = document.getElementById("summaryList");
const fio = document.getElementById("fio");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const city = document.getElementById("city");
const address = document.getElementById("address");
const zip = document.getElementById("zip");
const date = document.getElementById("date");
const item = document.getElementById("item");
const size = document.getElementById("size");
const qty = document.getElementById("qty");
const comment = document.getElementById("comment");
const agree = form.elements["agree"];

function getErrorBox(input) {
  if (input === agree) {
    return document.getElementById("agreeError");
  }
  return input.parentElement.querySelector(".error");
}

function showError(input, message) {
  const box = getErrorBox(input);
  box.textContent = message;
  box.classList.add("show");
  input.classList.add("invalid");
}

function clearError(input) {
  const box = getErrorBox(input);
  box.textContent = "";
  box.classList.remove("show");
  input.classList.remove("invalid");
}

function checkFio() {
  const value = fio.value.trim();
  if (value === "") {
    showError(fio, "Введите фамилию, имя и отчество.");
    return false;
  }
  if (!/^[А-Яа-яЁёA-Za-z\- ]+$/.test(value)) {
    showError(fio, "ФИО может содержать только буквы, пробелы и дефис.");
    return false;
  }
  if (value.split(/\s+/).length < 2) {
    showError(fio, "Введите минимум фамилию и имя.");
    return false;
  }
  return true;
}

function checkEmail() {
  const value = email.value.trim();
  if (value === "") {
    showError(email, "Введите электронную почту.");
    return false;
  }
  if (!/^[A-Za-z0-9._-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/.test(value)) {
    showError(email, "Почта введена неверно, пример: name@mail.com");
    return false;
  }
  return true;
}

function checkPhone() {
  const value = phone.value.replace(/[\s()-]/g, "");
  if (phone.value.trim() === "") {
    showError(phone, "Введите номер телефона.");
    return false;
  }
  if (!/^\+?[0-9]{10,13}$/.test(value)) {
    showError(phone, "Телефон должен состоять из 10-13 цифр, например +375291234567.");
    return false;
  }
  return true;
}

function checkCity() {
  const value = city.value.trim();
  if (value === "") {
    showError(city, "Введите город.");
    return false;
  }
  if (!/^[А-Яа-яЁёA-Za-z\- ]+$/.test(value)) {
    showError(city, "Название города может содержать только буквы.");
    return false;
  }
  return true;
}

function checkAddress() {
  const value = address.value.trim();
  if (value === "") {
    showError(address, "Введите адрес доставки.");
    return false;
  }
  if (value.length < 5) {
    showError(address, "Адрес слишком короткий.");
    return false;
  }
  return true;
}
function checkZip() {
  const value = zip.value.trim();
  if (value !== "" && !/^[0-9]{6}$/.test(value)) {
    showError(zip, "Индекс должен состоять из 6 цифр.");
    return false;
  }
  return true;
}

function checkDate() {
  const value = date.value;
  if (value === "") {
    return true;
  }
  const chosen = new Date(value);
  if (isNaN(chosen)) {
    showError(date, "Дата введена неверно.");
    return false;
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (chosen < today) {
    showError(date, "Дата доставки не может быть в прошлом.");
    return false;
  }
  return true;
}

function checkItem() {
  if (item.value === "") {
    showError(item, "Выберите товар.");
    return false;
  }
  return true;
}

function checkSize() {
  if (size.value === "") {
    showError(size, "Выберите размер.");
    return false;
  }
  return true;
}

function checkQty() {
  const value = qty.value.trim();
  if (value === "") {
    showError(qty, "Введите количество.");
    return false;
  }
  const number = Number(value);
  if (!Number.isInteger(number) || number < 1 || number > 10) {
    showError(qty, "Количество должно быть целым числом от 1 до 10.");
    return false;
  }
  return true;
}

function checkComment() {
  if (comment.value.length > 200) {
    showError(comment, "Комментарий не должен быть длиннее 200 символов.");
    return false;
  }
  return true;
}

function checkAgree() {
  if (!agree.checked) {
    showError(agree, "Нужно согласиться с условиями заказа.");
    return false;
  }
  return true;
}
const checks = [
  [fio, checkFio],
  [email, checkEmail],
  [phone, checkPhone],
  [city, checkCity],
  [address, checkAddress],
  [zip, checkZip],
  [date, checkDate],
  [item, checkItem],
  [size, checkSize],
  [qty, checkQty],
  [comment, checkComment],
  [agree, checkAgree]
];
for (let i = 0; i < checks.length; i++) {
  const input = checks[i][0];
  input.addEventListener("input", function () {
    clearError(input);
  });
  input.addEventListener("change", function () {
    clearError(input);
  });
}
function addRow(title, value) {
  const dt = document.createElement("dt");
  dt.textContent = title;
  const dd = document.createElement("dd");
  dd.textContent = value === "" ? "не указано" : value;
  summaryList.appendChild(dt);
  summaryList.appendChild(dd);
}

function showSummary() {
  summaryList.innerHTML = "";

  const deliveryRadio = form.querySelector('input[name="delivery"]:checked');
  const deliveryText = deliveryRadio.parentElement.textContent.trim();

  addRow("ФИО", fio.value.trim());
  addRow("Электронная почта", email.value.trim());
  addRow("Телефон", phone.value.trim());
  addRow("Город", city.value.trim());
  addRow("Адрес", address.value.trim());
  addRow("Почтовый индекс", zip.value.trim());
  addRow("Дата доставки", date.value);
  addRow("Способ доставки", deliveryText);
  addRow("Товар", item.options[item.selectedIndex].text);
  addRow("Размер", size.options[size.selectedIndex].text);
  addRow("Количество", qty.value.trim());
  addRow("Комментарий", comment.value.trim());
  addRow("Подарочная упаковка", form.elements["gift"].checked ? "да" : "нет");

  summary.classList.add("show");
  summary.scrollIntoView();
}

form.addEventListener("submit", function (event) {
  event.preventDefault();

  summary.classList.remove("show");
  let allCorrect = true;
  let firstWrong = null;

  for (let i = 0; i < checks.length; i++) {
    const input = checks[i][0];
    const check = checks[i][1];

    clearError(input);
    if (!check()) {
      allCorrect = false;
      if (firstWrong === null) {
        firstWrong = input;
      }
    }
  }

  if (!allCorrect) {
    firstWrong.focus();
    return;
  }

  showSummary();
  form.reset();
  date.type = "text";
});

form.addEventListener("reset", function () {
  for (let i = 0; i < checks.length; i++) {
    clearError(checks[i][0]);
  }
});
