function fibonacci(n) {
  let prev = 1n;   
  let current = 1n; 

  for (let i = 3; i <= n; i++) {
    let next = prev + current;
    prev = current;
    current = next;
  }

  return current;
}

const input = document.getElementById("n");
const button = document.getElementById("btn");
const result = document.getElementById("result");

button.addEventListener("click", function () {
  const n = Number(input.value);

  if (!Number.isInteger(n) || n < 1) {
    result.textContent = "Введите целое число N, не меньше 1.";
    return;
  }

  if (n > 5000) {
    result.textContent = "Слишком большое N, введите число до 5000.";
    return;
  }

  const answer = fibonacci(n);
  result.textContent = n + "-ый член ряда Фибоначчи: " + answer;
  console.log("N = " + n + ", член ряда Фибоначчи: " + answer);
});
