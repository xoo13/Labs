const arrayInput = document.getElementById("array");

function readArray() {
  const parts = arrayInput.value.trim().split(/[\s,;]+/);
  const numbers = [];

  for (let i = 0; i < parts.length; i++) {
    if (parts[i] === "") {
      continue;
    }
    const value = Number(parts[i]);
    if (isNaN(value)) {
      return null;
    }
    numbers[numbers.length] = value;
  }

  if (numbers.length === 0) {
    return null;
  }

  return numbers;
}

function sumBetween(arr) {
  const eps = 0.00001;
  let first = -1; 
  let last = -1;  
  for (let i = 0; i < arr.length; i++) {
    if (Math.abs(arr[i] - Math.PI) <= eps) {
      if (first === -1) {
        first = i;
      }
      last = i;
    }
  }

  
  if (first === -1 || first === last) {
    return null;
  }

  let sum = 0;
  for (let i = first + 1; i < last; i++) {
    sum += arr[i];
  }
  return sum;
}

document.getElementById("btnA").addEventListener("click", function () {
  const resultA = document.getElementById("resultA");
  const arr = readArray();

  if (arr === null) {
    resultA.textContent = "Ошибка: введите числа через пробел или запятую.";
    return;
  }

  const sum = sumBetween(arr);

  if (sum === null) {
    resultA.textContent = "В массиве меньше двух элементов, равных π (с точностью 10^-5), суммировать нечего.";
  } else {
    resultA.textContent = "Сумма элементов между первым и последним числом, равным π: " + sum;
  }
  console.log("Часть А:", sum);
});


function allDigitsOdd(x) {
  const integerPart = Math.trunc(Math.abs(x));
  const digits = String(integerPart).split("");

  return digits.every(function (d) {
    return Number(d) % 2 === 1;
  });
}

document.getElementById("btnB").addEventListener("click", function () {
  const resultB = document.getElementById("resultB");
  const arr = readArray();

  if (arr === null) {
    resultB.textContent = "Ошибка: введите числа через пробел или запятую.";
    return;
  }

  const newArr = arr.filter(function (x) {
    return !allDigitsOdd(x);
  });

  if (newArr.length === 0) {
    resultB.textContent = "Все элементы удалены, массив пустой.";
  } else {
    resultB.textContent = "Массив после удаления: " + newArr.join(", ");
  }
  console.log("Часть Б:", newArr);
});
