function changeCase(word) {
  let newWord = "";

  for (let i = 0; i < word.length; i++) {
    if (i % 2 === 0) {
      newWord += word[i].toUpperCase();
    } else {
      newWord += word[i].toLowerCase();
    }
  }
  return newWord;
}

const input = document.getElementById("word");
const button = document.getElementById("btn");
const result = document.getElementById("result");

button.addEventListener("click", function () {
  const word = input.value.trim();

  if (word === "") {
    result.textContent = "Введите слово.";
    return;
  }

  if (word.indexOf(" ") !== -1) {
    result.textContent = "Нужно ввести одно слово, без пробелов.";
    return;
  }

  const answer = changeCase(word);
  result.textContent = answer;
  console.log(word + " -> " + answer);
});
